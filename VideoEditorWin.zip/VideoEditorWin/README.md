# Video Editor for Windows 11

Same features as the Android app: lossless trim, draggable crop, near-lossless compress, join with reordering.
Built with Python + PySide6 (Qt) and FFmpeg.

## Easiest: download the finished app
Push this project to GitHub with the workflow (see below). Each push builds `VideoEditor-Windows.zip`
and attaches it to a Release. Unzip it anywhere and run `VideoEditor.exe`. No install needed.
(Windows SmartScreen may warn because the exe is unsigned: More info > Run anyway.)

## Run from source
1. Install Python 3.10+ from python.org (tick "Add python.exe to PATH").
2. Get FFmpeg: put `ffmpeg.exe` and `ffprobe.exe` in the `ffmpeg` folder, or run `winget install Gyan.FFmpeg`.
3. Double-click `run.bat`.

## Build the .exe yourself
Put ffmpeg.exe + ffprobe.exe in `ffmpeg\`, then double-click `build_exe.bat`.
Result: `dist\VideoEditor\VideoEditor.exe` (zip the whole folder to share it).

## How to use
- **Add videos**: "+ Add" or drag files onto the window.
- **Trim**: drag the orange handles on the timeline (or "Set start/end at playhead"), then SAVE.
  Default is a lossless stream copy. It is instant and loses nothing, but cuts snap to the nearest keyframe.
  Tick "Frame-accurate" for an exact cut (re-encodes).
- **Crop**: drag the box, or pick a ratio. Scrub the timeline to choose which frame you see. SAVE re-encodes.
- **Compress**: pick Near-lossless (CRF 18), Balanced (22) or Small (26), optionally cap the resolution.
- **Join**: order clips with the arrows. Same-format clips are joined losslessly; others are re-encoded to the first clip's size.
- Encoders: HEVC/H.264 on CPU (best quality per size), or GPU encoders (NVIDIA / Intel QSV / AMD) for speed.
  GPU encoders need a matching GPU and driver.

## Notes
- Output is always a new file; your originals are never touched.
- Audio is copied untouched except when joining mixed-format clips (re-encoded to AAC).
- The bundled FFmpeg build is GPL (includes x264/x265), so redistribute the app under GPL-compatible terms.
