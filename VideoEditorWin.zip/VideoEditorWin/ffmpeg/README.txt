Place ffmpeg.exe and ffprobe.exe in this folder (the CI workflow does this automatically).
