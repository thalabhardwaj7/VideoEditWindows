"""
Video Editor for Windows 11
Lossless trim, draggable frame crop, near-lossless compress, join with reordering.
UI: PySide6 (Qt).  Engine: FFmpeg / FFprobe.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal, QUrl, QRectF, QTimer
from PySide6.QtGui import QPixmap, QImage, QPainter, QColor, QPen, QIcon
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QSlider, QListWidget, QFileDialog, QStackedWidget, QComboBox, QButtonGroup, QCheckBox,
    QProgressBar, QMessageBox, QGroupBox,
)

ORANGE = QColor("#FF5A1F")
NO_WINDOW = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


# ----------------------------------------------------------------------------
# paths / ffmpeg
# ----------------------------------------------------------------------------
def resource(rel: str) -> str:
    base = getattr(sys, "_MEIPASS", None) or Path(__file__).parent
    return str(Path(base) / rel)


def find_tool(name: str) -> str:
    exe = name + (".exe" if os.name == "nt" else "")
    for cand in (Path(resource("ffmpeg")) / exe, Path(__file__).parent / "ffmpeg" / exe):
        if cand.exists():
            return str(cand)
    return shutil.which(name) or name


FFMPEG = find_tool("ffmpeg")
FFPROBE = find_tool("ffprobe")


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, creationflags=NO_WINDOW, **kw)


def fmt_time(sec: float) -> str:
    sec = max(sec, 0)
    return f"{int(sec // 60)}:{sec % 60:04.1f}"


def fmt_mb(b: int) -> str:
    return f"{b / 1_000_000:.1f} MB"


# ----------------------------------------------------------------------------
# clip info
# ----------------------------------------------------------------------------
@dataclass
class Clip:
    path: str
    duration: float
    w: int            # displayed width (rotation applied)
    h: int
    fps: float
    vcodec: str
    pix_fmt: str
    has_audio: bool
    acodec: str
    arate: str
    size: int

    @property
    def name(self):
        return Path(self.path).name

    def join_key(self):
        return (self.vcodec, self.w, self.h, round(self.fps, 2), self.pix_fmt,
                self.has_audio, self.acodec, self.arate)


def probe(path: str) -> Clip:
    r = run([FFPROBE, "-v", "error", "-show_streams", "-show_format", "-of", "json", path])
    j = json.loads(r.stdout.decode("utf-8", "replace"))
    streams = j.get("streams", [])
    v = next(s for s in streams if s.get("codec_type") == "video")
    a = next((s for s in streams if s.get("codec_type") == "audio"), None)
    w, h = int(v["width"]), int(v["height"])
    rot = 0
    for sd in v.get("side_data_list") or []:
        if "rotation" in sd:
            rot = int(float(sd["rotation"]))
    if "rotate" in (v.get("tags") or {}):
        rot = int(v["tags"]["rotate"])
    if abs(rot) % 180 == 90:
        w, h = h, w
    try:
        num, den = v.get("avg_frame_rate", "0/1").split("/")
        fps = float(num) / float(den) if float(den) else 0.0
    except Exception:
        fps = 0.0
    dur = float(j.get("format", {}).get("duration") or v.get("duration") or 0)
    size = int(j.get("format", {}).get("size") or os.path.getsize(path))
    return Clip(path, dur, w, h, fps or 30.0, v.get("codec_name", ""), v.get("pix_fmt", ""),
                a is not None, (a or {}).get("codec_name", ""), (a or {}).get("sample_rate", ""), size)


def grab_frame(path: str, t: float) -> QPixmap:
    r = run([FFMPEG, "-v", "error", "-ss", f"{max(t, 0):.3f}", "-i", path, "-frames:v", "1",
             "-f", "image2pipe", "-vcodec", "png", "-"])
    img = QImage.fromData(r.stdout)
    return QPixmap.fromImage(img)


# ----------------------------------------------------------------------------
# encoders
# ----------------------------------------------------------------------------
ENCODERS = [
    ("HEVC / H.265 (CPU, smallest)", "x265"),
    ("H.264 (CPU, most compatible)", "x264"),
    ("HEVC NVIDIA GPU", "nvenc"),
    ("HEVC Intel GPU (QSV)", "qsv"),
    ("HEVC AMD GPU", "amf"),
]


def venc_args(kind: str, crf: int):
    c = str(crf)
    if kind == "x265":
        return ["-c:v", "libx265", "-crf", c, "-preset", "medium", "-tag:v", "hvc1",
                "-x265-params", "log-level=error"]
    if kind == "x264":
        return ["-c:v", "libx264", "-crf", c, "-preset", "slow"]
    if kind == "nvenc":
        return ["-c:v", "hevc_nvenc", "-rc", "vbr", "-cq", c, "-b:v", "0", "-preset", "p5", "-tag:v", "hvc1"]
    if kind == "qsv":
        return ["-c:v", "hevc_qsv", "-global_quality", c, "-preset", "slower", "-tag:v", "hvc1"]
    if kind == "amf":
        return ["-c:v", "hevc_amf", "-rc", "cqp", "-qp_i", c, "-qp_p", c, "-quality", "quality", "-tag:v", "hvc1"]
    raise ValueError(kind)


def join_reencode_args(clips, kind, crf):
    W, H = clips[0].w - clips[0].w % 2, clips[0].h - clips[0].h % 2
    fps = clips[0].fps or 30
    audio = all(c.has_audio for c in clips)
    args, parts = [], []
    for c in clips:
        args += ["-i", c.path]
    for i in range(len(clips)):
        parts.append(f"[{i}:v]scale={W}:{H}:force_original_aspect_ratio=decrease,"
                     f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps:.3f}[v{i}]")
        if audio:
            parts.append(f"[{i}:a]aresample=48000,aformat=channel_layouts=stereo[a{i}]")
    ins = "".join(f"[v{i}]" + (f"[a{i}]" if audio else "") for i in range(len(clips)))
    parts.append(f"{ins}concat=n={len(clips)}:v=1:a={1 if audio else 0}[v]" + ("[a]" if audio else ""))
    args += ["-filter_complex", ";".join(parts), "-map", "[v]"]
    if audio:
        args += ["-map", "[a]"]
    args += venc_args(kind, crf)
    if audio:
        args += ["-c:a", "aac", "-b:a", "192k"]
    return args


# ----------------------------------------------------------------------------
# background jobs
# ----------------------------------------------------------------------------
class Job(QThread):
    progress = Signal(int)
    result = Signal(bool, str)

    def __init__(self, args, total_sec):
        super().__init__()
        self.args, self.total = args, total_sec
        self.proc = None

    def run(self):
        cmd = [FFMPEG, "-y", "-hide_banner", "-v", "error", "-progress", "pipe:1", "-nostats"] + self.args
        tail = []
        try:
            self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                         encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
            for line in self.proc.stdout:
                line = line.strip()
                if line.startswith(("out_time_us=", "out_time_ms=")):
                    try:
                        t = int(line.split("=")[1]) / 1e6
                        if self.total > 0:
                            self.progress.emit(min(99, int(t / self.total * 100)))
                    except ValueError:
                        pass
                elif "=" not in line and line:
                    tail.append(line)
                elif line.startswith(("Error", "[")):
                    tail.append(line)
            rc = self.proc.wait()
            if rc == 0:
                self.progress.emit(100)
                self.result.emit(True, "")
            else:
                self.result.emit(False, "\n".join(tail[-12:]) or f"ffmpeg exited with code {rc}")
        except Exception as e:  # noqa: BLE001
            self.result.emit(False, str(e))

    def cancel(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()


class StripJob(QThread):
    ready = Signal(str, object)

    def __init__(self, path, duration, n=12):
        super().__init__()
        self.path, self.duration, self.n = path, duration, n

    def run(self):
        d = max(self.duration, 0.1)
        r = run([FFMPEG, "-v", "error", "-i", self.path, "-vf",
                 f"fps={self.n / d:.5f},scale=160:-2,tile={self.n}x1", "-frames:v", "1",
                 "-f", "image2pipe", "-vcodec", "png", "-"])
        self.ready.emit(self.path, r.stdout)


# ----------------------------------------------------------------------------
# timeline (scrub + trim handles)
# ----------------------------------------------------------------------------
class TimelineBar(QWidget):
    scrubbed = Signal(float)
    rangeChanged = Signal(float, float)

    def __init__(self):
        super().__init__()
        self.setMinimumHeight(72)
        self.strip = None
        self.pos, self.a, self.b = 0.0, 0.0, 1.0
        self.range_mode = False
        self._drag = None

    def set_strip(self, pm):
        self.strip = pm
        self.update()

    def reset(self):
        self.pos, self.a, self.b = 0.0, 0.0, 1.0
        self.update()

    def _r(self):
        return self.rect().adjusted(10, 12, -10, -12)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self._r()
        p.fillRect(r, QColor("#E6E6E6"))
        if self.strip and not self.strip.isNull():
            p.drawPixmap(r, self.strip)
        if self.range_mode:
            dim = QColor(0, 0, 0, 150)
            x0, x1 = r.left() + self.a * r.width(), r.left() + self.b * r.width()
            p.fillRect(QRectF(r.left(), r.top(), x0 - r.left(), r.height()), dim)
            p.fillRect(QRectF(x1, r.top(), r.right() - x1, r.height()), dim)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(ORANGE)
            for x in (x0, x1):
                p.drawRoundedRect(QRectF(x - 4, r.top() - 5, 8, r.height() + 10), 3, 3)
        x = r.left() + self.pos * r.width()
        p.fillRect(QRectF(x - 1.5, r.top() - 8, 3, r.height() + 16), ORANGE)

    def _frac(self, x):
        r = self._r()
        return min(max((x - r.left()) / max(r.width(), 1), 0.0), 1.0)

    def mousePressEvent(self, e):
        r = self._r()
        x = e.position().x()
        f = self._frac(x)
        self._drag = "play"
        if self.range_mode:
            xa, xb = r.left() + self.a * r.width(), r.left() + self.b * r.width()
            if abs(x - xa) < 12 and abs(x - xa) <= abs(x - xb):
                self._drag = "a"
            elif abs(x - xb) < 12:
                self._drag = "b"
        self._apply(f)

    def mouseMoveEvent(self, e):
        if self._drag:
            self._apply(self._frac(e.position().x()))

    def mouseReleaseEvent(self, _):
        self._drag = None

    def _apply(self, f):
        if self._drag == "a":
            self.a = min(f, self.b - 0.01)
            self.pos = self.a
            self.rangeChanged.emit(self.a, self.b)
        elif self._drag == "b":
            self.b = max(f, self.a + 0.01)
            self.pos = self.b
            self.rangeChanged.emit(self.a, self.b)
        else:
            self.pos = f
        self.update()
        self.scrubbed.emit(self.pos)


# ----------------------------------------------------------------------------
# crop canvas (draggable box on a still frame)
# ----------------------------------------------------------------------------
def centered_rect(lock, vaspect):
    if not lock:
        return (0.05, 0.05, 0.95, 0.95)
    nw = 0.9
    nh = nw * vaspect * lock[1] / lock[0]
    if nh > 0.9:
        nh = 0.9
        nw = nh * lock[0] / (vaspect * lock[1])
    l, t = (1 - nw) / 2, (1 - nh) / 2
    return (l, t, l + nw, t + nh)


def resize_rect(old, ax, ay, mx, my, lock, vaspect):
    nw, nh = abs(mx - ax), abs(my - ay)
    if lock:
        nh = nw * vaspect * lock[1] / lock[0]
    if nw < 0.05 or nh < 0.05:
        return old
    ex = ax + (nw if mx >= ax else -nw)
    ey = ay + (nh if my >= ay else -nh)
    if not (0 <= ex <= 1 and 0 <= ey <= 1):
        return old
    return (min(ax, ex), min(ay, ey), max(ax, ex), max(ay, ey))


class CropCanvas(QWidget):
    changed = Signal()

    def __init__(self):
        super().__init__()
        self.pm = None
        self.rect_n = (0.05, 0.05, 0.95, 0.95)   # normalized l,t,r,b
        self.lock = None
        self.mode = 0
        self.last = None
        self.setMinimumSize(300, 200)

    @property
    def vaspect(self):
        return self.pm.width() / self.pm.height() if self.pm and not self.pm.isNull() else 16 / 9

    def set_pixmap(self, pm):
        self.pm = pm
        self.update()
        self.changed.emit()

    def set_lock(self, lock):
        self.lock = lock
        self.rect_n = centered_rect(lock, self.vaspect)
        self.update()
        self.changed.emit()

    def reset(self):
        self.set_lock(None)

    def _fit(self):
        if not self.pm or self.pm.isNull():
            return QRectF(0, 0, 1, 1)
        W, H = self.width(), self.height()
        s = min(W / self.pm.width(), H / self.pm.height())
        w, h = self.pm.width() * s, self.pm.height() * s
        return QRectF((W - w) / 2, (H - h) / 2, w, h)

    def pixel_rect(self):
        if not self.pm or self.pm.isNull():
            return 0, 0, 2, 2
        l, t, r, b = self.rect_n
        W, H = self.pm.width(), self.pm.height()
        x, y = int(l * W) & ~1, int(t * H) & ~1
        w, h = max(int((r - l) * W) & ~1, 2), max(int((b - t) * H) & ~1, 2)
        return x, y, min(w, W - x), min(h, H - y)

    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), Qt.GlobalColor.black)
        if not self.pm or self.pm.isNull():
            p.setPen(Qt.GlobalColor.white)
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Add a video to crop")
            return
        f = self._fit()
        p.drawPixmap(f.toRect(), self.pm)
        l, t, r, b = self.rect_n
        x0, y0 = f.left() + l * f.width(), f.top() + t * f.height()
        x1, y1 = f.left() + r * f.width(), f.top() + b * f.height()
        dim = QColor(0, 0, 0, 150)
        p.fillRect(QRectF(f.left(), f.top(), f.width(), y0 - f.top()), dim)
        p.fillRect(QRectF(f.left(), y1, f.width(), f.bottom() - y1), dim)
        p.fillRect(QRectF(f.left(), y0, x0 - f.left(), y1 - y0), dim)
        p.fillRect(QRectF(x1, y0, f.right() - x1, y1 - y0), dim)
        p.setPen(QPen(Qt.GlobalColor.white, 2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(QRectF(x0, y0, x1 - x0, y1 - y0))
        p.setPen(QPen(QColor(255, 255, 255, 120), 1))
        for i in (1, 2):
            xx, yy = x0 + (x1 - x0) * i / 3, y0 + (y1 - y0) * i / 3
            p.drawLine(int(xx), int(y0), int(xx), int(y1))
            p.drawLine(int(x0), int(yy), int(x1), int(yy))
        p.setPen(QPen(Qt.GlobalColor.white, 2))
        p.setBrush(ORANGE)
        for cx, cy in ((x0, y0), (x1, y0), (x0, y1), (x1, y1)):
            p.drawEllipse(QRectF(cx - 8, cy - 8, 16, 16))

    def mousePressEvent(self, e):
        if not self.pm or self.pm.isNull():
            return
        f = self._fit()
        pos = e.position()
        l, t, r, b = self.rect_n
        pts = [(f.left() + l * f.width(), f.top() + t * f.height()),
               (f.left() + r * f.width(), f.top() + t * f.height()),
               (f.left() + l * f.width(), f.top() + b * f.height()),
               (f.left() + r * f.width(), f.top() + b * f.height())]
        self.mode = 0
        for i, (px, py) in enumerate(pts):
            if (pos.x() - px) ** 2 + (pos.y() - py) ** 2 < 20 ** 2:
                self.mode = 2 + i
                break
        else:
            nx, ny = (pos.x() - f.left()) / f.width(), (pos.y() - f.top()) / f.height()
            if l <= nx <= r and t <= ny <= b:
                self.mode = 1
        self.last = pos

    def mouseMoveEvent(self, e):
        if not self.mode or self.last is None:
            return
        f = self._fit()
        pos = e.position()
        dx, dy = (pos.x() - self.last.x()) / f.width(), (pos.y() - self.last.y()) / f.height()
        self.last = pos
        l, t, r, b = self.rect_n
        va, lk = self.vaspect, self.lock
        if self.mode == 1:
            w, h = r - l, b - t
            nl, nt = min(max(l + dx, 0), 1 - w), min(max(t + dy, 0), 1 - h)
            new = (nl, nt, nl + w, nt + h)
        elif self.mode == 2:
            new = resize_rect(self.rect_n, r, b, l + dx, t + dy, lk, va)
        elif self.mode == 3:
            new = resize_rect(self.rect_n, l, b, r + dx, t + dy, lk, va)
        elif self.mode == 4:
            new = resize_rect(self.rect_n, r, t, l + dx, b + dy, lk, va)
        else:
            new = resize_rect(self.rect_n, l, t, r + dx, b + dy, lk, va)
        if new != self.rect_n:
            self.rect_n = new
            self.update()
            self.changed.emit()

    def mouseReleaseEvent(self, _):
        self.mode = 0


# ----------------------------------------------------------------------------
# main window
# ----------------------------------------------------------------------------
QSS = """
QWidget { font-family: 'Segoe UI'; font-size: 13px; color: #222; }
QMainWindow, QWidget#root { background: #F8F8F8; }
QPushButton { background: white; border: 1px solid #DDD; border-radius: 6px; padding: 7px 12px; }
QPushButton:hover { border-color: #FF5A1F; }
QPushButton:checked { background: #FF5A1F; color: white; border-color: #FF5A1F; }
QPushButton:disabled { color: #AAA; }
QPushButton#save { background: #FF5A1F; color: white; font-weight: 600; font-size: 15px; padding: 11px; border: none; }
QPushButton#save:disabled { background: #FFB59B; }
QSlider::groove:horizontal { height: 4px; background: #DDD; border-radius: 2px; }
QSlider::sub-page:horizontal { background: #FF5A1F; border-radius: 2px; }
QSlider::handle:horizontal { background: #FF5A1F; width: 16px; margin: -6px 0; border-radius: 8px; }
QProgressBar { border: none; background: #E6E6E6; border-radius: 4px; max-height: 8px; }
QProgressBar::chunk { background: #FF5A1F; border-radius: 4px; }
QListWidget { background: white; border: 1px solid #DDD; border-radius: 6px; }
QListWidget::item { padding: 6px; }
QListWidget::item:selected { background: #FFE3D8; color: #222; }
QComboBox { background: white; border: 1px solid #DDD; border-radius: 6px; padding: 5px 8px; }
QGroupBox { border: 1px solid #E2E2E2; border-radius: 8px; margin-top: 10px; padding: 12px 8px 8px 8px; background: white; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #666; }
QLabel#hint { color: #666; }
"""

TOOLS = [("crop", "Crop"), ("trim", "Trim"), ("join", "Join"), ("compress", "Compress")]


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Video Editor")
        self.resize(1240, 780)
        self.clips: list[Clip] = []
        self.tool = "crop"
        self.job = None
        self.keep = []
        self.tmpdir = None

        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        outer = QHBoxLayout(root)

        # ---------- left: preview + transport + timeline ----------
        left = QVBoxLayout()
        self.stack = QStackedWidget()
        self.video = QVideoWidget()
        self.crop = CropCanvas()
        self.stack.addWidget(self.video)
        self.stack.addWidget(self.crop)
        left.addWidget(self.stack, 1)

        tr = QHBoxLayout()
        self.btn_start = QPushButton("⏮")
        self.btn_play = QPushButton("▶  Play")
        self.btn_start.setFixedWidth(46)
        self.btn_play.setFixedWidth(100)
        self.lbl_time = QLabel("0:00.0 / 0:00.0")
        tr.addWidget(self.btn_start)
        tr.addWidget(self.btn_play)
        tr.addStretch(1)
        tr.addWidget(self.lbl_time)
        left.addLayout(tr)
        self.tl = TimelineBar()
        left.addWidget(self.tl)
        outer.addLayout(left, 1)

        # ---------- right: tools / options / clips / save ----------
        right = QVBoxLayout()
        wrap = QWidget()
        wrap.setFixedWidth(360)
        wrap.setLayout(right)
        outer.addWidget(wrap)

        row = QHBoxLayout()
        self.tool_group = QButtonGroup(self)
        self.tool_group.setExclusive(True)
        self.tool_btns = {}
        for key, label in TOOLS:
            b = QPushButton(label)
            b.setCheckable(True)
            self.tool_group.addButton(b)
            self.tool_btns[key] = b
            row.addWidget(b)
            b.clicked.connect(lambda _=False, k=key: self.set_tool(k))
        right.addLayout(row)

        self.opts = QStackedWidget()
        right.addWidget(self.opts)
        self._build_pages()

        enc_box = QGroupBox("Output quality (used when re-encoding)")
        ev = QVBoxLayout(enc_box)
        self.enc = QComboBox()
        for name, _ in ENCODERS:
            self.enc.addItem(name)
        ev.addWidget(self.enc)
        ph = QHBoxLayout()
        for label, v in (("Near-lossless", 18), ("Balanced", 22), ("Small", 26)):
            b = QPushButton(label)
            b.clicked.connect(lambda _=False, val=v: self.crf.setValue(val))
            ph.addWidget(b)
        ev.addLayout(ph)
        sh = QHBoxLayout()
        self.crf = QSlider(Qt.Orientation.Horizontal)
        self.crf.setRange(12, 34)
        self.crf.setValue(20)
        self.lbl_crf = QLabel("CRF 20")
        self.crf.valueChanged.connect(lambda v: self.lbl_crf.setText(f"CRF {v}"))
        sh.addWidget(self.crf)
        sh.addWidget(self.lbl_crf)
        ev.addLayout(sh)
        n = QLabel("Lower number = higher quality, bigger file. 18 is visually lossless for most videos.")
        n.setObjectName("hint")
        n.setWordWrap(True)
        ev.addWidget(n)
        right.addWidget(enc_box)

        clip_box = QGroupBox("Clips")
        cv = QVBoxLayout(clip_box)
        self.list = QListWidget()
        cv.addWidget(self.list)
        cb = QHBoxLayout()
        self.btn_add = QPushButton("+ Add")
        self.btn_up = QPushButton("↑")
        self.btn_down = QPushButton("↓")
        self.btn_del = QPushButton("Remove")
        for b in (self.btn_add, self.btn_up, self.btn_down, self.btn_del):
            cb.addWidget(b)
        cv.addLayout(cb)
        right.addWidget(clip_box, 1)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setTextVisible(False)
        right.addWidget(self.progress)
        self.btn_save = QPushButton("SAVE")
        self.btn_save.setObjectName("save")
        right.addWidget(self.btn_save)

        # ---------- player ----------
        self.player = QMediaPlayer()
        self.audio = QAudioOutput()
        self.player.setAudioOutput(self.audio)
        self.player.setVideoOutput(self.video)
        self.frame_timer = QTimer(self)
        self.frame_timer.setSingleShot(True)
        self.frame_timer.setInterval(180)
        self.frame_timer.timeout.connect(self.refresh_crop_frame)

        # ---------- wiring ----------
        self.btn_add.clicked.connect(self.add_files)
        self.btn_del.clicked.connect(self.remove_clip)
        self.btn_up.clicked.connect(lambda: self.move_clip(-1))
        self.btn_down.clicked.connect(lambda: self.move_clip(1))
        self.list.currentRowChanged.connect(self.on_select)
        self.btn_play.clicked.connect(self.toggle_play)
        self.btn_start.clicked.connect(lambda: self.seek_frac(0.0))
        self.player.positionChanged.connect(self.on_position)
        self.player.playbackStateChanged.connect(self.on_state)
        self.tl.scrubbed.connect(self.on_scrub)
        self.tl.rangeChanged.connect(self.on_range)
        self.crop.changed.connect(self.update_crop_label)
        self.btn_save.clicked.connect(self.save)

        self.tool_btns["crop"].setChecked(True)
        self.set_tool("crop")
        self.setAcceptDrops(True)

    # ---------------- option pages ----------------
    def _page(self, widgets):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        g = QGroupBox()
        gv = QVBoxLayout(g)
        for x in widgets:
            gv.addWidget(x)
        v.addWidget(g)
        self.opts.addWidget(w)
        return w

    def _hint(self, text):
        l = QLabel(text)
        l.setObjectName("hint")
        l.setWordWrap(True)
        return l

    def _build_pages(self):
        # crop
        self.aspect = QComboBox()
        self.aspects = [("Free", None), ("1:1", (1, 1)), ("9:16", (9, 16)), ("16:9", (16, 9)),
                        ("4:5", (4, 5)), ("3:4", (3, 4)), ("4:3", (4, 3))]
        for n, _ in self.aspects:
            self.aspect.addItem(n)
        self.aspect.currentIndexChanged.connect(lambda i: self.crop.set_lock(self.aspects[i][1]))
        self.lbl_crop = QLabel("Crop: -")
        self.lbl_crop.setStyleSheet("font-weight:600;")
        self.page_crop = self._page([QLabel("Aspect ratio"), self.aspect, self.lbl_crop,
                                     self._hint("Drag inside the box to move it, drag a corner to resize. "
                                                "Scrub the timeline to pick a different preview frame. "
                                                "Crop re-encodes the picture; audio is copied untouched.")])
        # trim
        self.lbl_range = QLabel("Range: -")
        self.lbl_range.setStyleSheet("font-weight:600;")
        b1, b2 = QPushButton("Set start at playhead"), QPushButton("Set end at playhead")
        b1.clicked.connect(lambda: self.set_range_from_playhead("a"))
        b2.clicked.connect(lambda: self.set_range_from_playhead("b"))
        self.accurate = QCheckBox("Frame-accurate cut (re-encodes)")
        self.page_trim = self._page([self.lbl_range, b1, b2, self.accurate,
                                     self._hint("Default is a lossless cut: no re-encode, instant, zero quality loss. "
                                                "Cuts snap to the nearest keyframe. Tick the box above for an exact "
                                                "frame cut.")])
        # join
        self.lbl_join = QLabel("Add 2 or more clips")
        self.lbl_join.setStyleSheet("font-weight:600;")
        self.page_join = self._page([self.lbl_join,
                                     self._hint("Use the arrows in the Clips list to reorder. Clips with the same "
                                                "codec, size and frame rate join without re-encoding (lossless). "
                                                "Otherwise they are re-encoded to the first clip's size.")])
        # compress
        self.maxh = QComboBox()
        for label, v in (("Keep original size", 0), ("Max 1080p", 1080), ("Max 720p", 720), ("Max 480p", 480)):
            self.maxh.addItem(label, v)
        self.page_comp = self._page([QLabel("Resolution"), self.maxh,
                                     self._hint("Near-lossless compression: same picture size and frame rate, "
                                                "much lower bitrate. Pick Near-lossless below for the best look.")])
        self.pages = {"crop": self.page_crop, "trim": self.page_trim,
                      "join": self.page_join, "compress": self.page_comp}

    # ---------------- helpers ----------------
    def cur(self):
        r = self.list.currentRow()
        return self.clips[r] if 0 <= r < len(self.clips) else None

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        self._load_paths([u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()])

    # ---------------- clips ----------------
    def add_files(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Add videos", "", "Video files (*.mp4 *.mov *.mkv *.avi *.webm *.m4v *.ts *.wmv);;All files (*.*)")
        self._load_paths(paths)

    def _load_paths(self, paths):
        first_new = len(self.clips)
        for p in paths:
            try:
                self.clips.append(probe(p))
            except Exception as e:  # noqa: BLE001
                QMessageBox.warning(self, "Cannot open", f"{Path(p).name}\n\n{e}")
        self.refresh_list()
        if len(self.clips) > first_new:
            self.list.setCurrentRow(first_new if first_new < len(self.clips) else 0)
        self.update_join_label()

    def refresh_list(self, keep_row=None):
        row = self.list.currentRow() if keep_row is None else keep_row
        self.list.blockSignals(True)
        self.list.clear()
        for i, c in enumerate(self.clips):
            self.list.addItem(f"{i + 1}. {c.name}   {fmt_time(c.duration)}  {c.w}×{c.h}")
        if self.clips:
            self.list.setCurrentRow(min(max(row, 0), len(self.clips) - 1))
        self.list.blockSignals(False)

    def remove_clip(self):
        r = self.list.currentRow()
        if 0 <= r < len(self.clips):
            del self.clips[r]
            self.refresh_list(r)
            self.update_join_label()
            if self.clips:
                self.on_select(self.list.currentRow())
            else:
                self.player.setSource(QUrl())
                self.tl.set_strip(None)
                self.tl.reset()
                self.crop.set_pixmap(None)

    def move_clip(self, d):
        r = self.list.currentRow()
        n = r + d
        if 0 <= r < len(self.clips) and 0 <= n < len(self.clips):
            self.clips[r], self.clips[n] = self.clips[n], self.clips[r]
            self.refresh_list(n)
            self.update_join_label()

    def update_join_label(self):
        if len(self.clips) < 2:
            self.lbl_join.setText("Add 2 or more clips")
            return
        same = len({c.join_key() for c in self.clips}) == 1
        self.lbl_join.setText(f"{len(self.clips)} clips: " + ("same format, join will be LOSSLESS"
                                                              if same else "different formats, join will re-encode"))

    def on_select(self, row):
        c = self.cur()
        if not c:
            return
        self.player.setSource(QUrl.fromLocalFile(c.path))
        self.tl.reset()
        self.tl.set_strip(None)
        self.on_range(0.0, 1.0)
        self.lbl_time.setText(f"0:00.0 / {fmt_time(c.duration)}")
        sj = StripJob(c.path, c.duration)
        sj.ready.connect(self.on_strip)
        sj.finished.connect(lambda s=sj: self.keep.remove(s) if s in self.keep else None)
        self.keep.append(sj)
        sj.start()
        if self.tool == "crop":
            self.crop.set_pixmap(grab_frame(c.path, 0))
            self.crop.reset()
            self.aspect.setCurrentIndex(0)

    def on_strip(self, path, data):
        c = self.cur()
        if c and c.path == path and data:
            self.tl.set_strip(QPixmap.fromImage(QImage.fromData(data)))

    # ---------------- tools ----------------
    def set_tool(self, key):
        self.tool = key
        self.opts.setCurrentWidget(self.pages[key])
        self.tl.range_mode = key == "trim"
        self.tl.update()
        self.player.pause()
        if key == "crop":
            self.stack.setCurrentWidget(self.crop)
            self.refresh_crop_frame()
        else:
            self.stack.setCurrentWidget(self.video)

    def refresh_crop_frame(self):
        c = self.cur()
        if c:
            first = self.crop.pm is None or self.crop.pm.isNull()
            self.crop.set_pixmap(grab_frame(c.path, self.player.position() / 1000.0))
            if first:
                self.crop.reset()

    def update_crop_label(self):
        x, y, w, h = self.crop.pixel_rect()
        self.lbl_crop.setText(f"Crop: {w} × {h}  at ({x}, {y})")

    def on_range(self, a, b):
        c = self.cur()
        d = c.duration if c else 0
        self.lbl_range.setText(f"Range: {fmt_time(a * d)} – {fmt_time(b * d)}   ({fmt_time((b - a) * d)})")

    def set_range_from_playhead(self, which):
        f = self.tl.pos
        if which == "a":
            self.tl.a = min(f, self.tl.b - 0.01)
        else:
            self.tl.b = max(f, self.tl.a + 0.01)
        self.tl.update()
        self.on_range(self.tl.a, self.tl.b)

    # ---------------- playback ----------------
    def toggle_play(self):
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        else:
            c = self.cur()
            if c and self.tool == "trim" and self.tl.pos >= self.tl.b - 0.001:
                self.seek_frac(self.tl.a)
            self.player.play()

    def on_state(self, st):
        playing = st == QMediaPlayer.PlaybackState.PlayingState
        self.btn_play.setText("⏸  Pause" if playing else "▶  Play")
        if self.tool == "crop":
            if playing:
                self.stack.setCurrentWidget(self.video)
            else:
                self.stack.setCurrentWidget(self.crop)
                self.frame_timer.start()

    def seek_frac(self, f):
        c = self.cur()
        if c:
            self.tl.pos = f
            self.tl.update()
            self.player.setPosition(int(f * c.duration * 1000))

    def on_scrub(self, f):
        c = self.cur()
        if not c:
            return
        self.player.setPosition(int(f * c.duration * 1000))
        self.lbl_time.setText(f"{fmt_time(f * c.duration)} / {fmt_time(c.duration)}")
        if self.tool == "crop":
            self.frame_timer.start()

    def on_position(self, ms):
        c = self.cur()
        if not c or c.duration <= 0:
            return
        f = ms / 1000.0 / c.duration
        playing = self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState
        if self.tool == "trim" and playing and f >= self.tl.b:
            self.player.pause()
            self.seek_frac(self.tl.a)
            return
        if self.tl._drag is None:
            self.tl.pos = min(f, 1.0)
            self.tl.update()
        self.lbl_time.setText(f"{fmt_time(ms / 1000.0)} / {fmt_time(c.duration)}")

    # ---------------- save ----------------
    def save(self):
        c = self.cur()
        if not c:
            QMessageBox.information(self, "Video Editor", "Add a video first.")
            return
        t = self.tool
        suffix = {"crop": "_crop", "trim": "_trim", "join": "_joined", "compress": "_small"}[t]
        base = Path(c.path)
        out, _ = QFileDialog.getSaveFileName(self, "Save as", str(base.with_name(base.stem + suffix + ".mp4")),
                                             "MP4 video (*.mp4)")
        if not out:
            return
        if any(Path(out).resolve() == Path(x.path).resolve() for x in self.clips):
            QMessageBox.warning(self, "Video Editor", "Choose a different file name than the source.")
            return

        kind = ENCODERS[self.enc.currentIndex()][1]
        crf = self.crf.value()
        total = c.duration
        base_map = ["-map", "0:v:0", "-map", "0:a?"]

        if t == "trim":
            a, b = self.tl.a * c.duration, self.tl.b * c.duration
            d = b - a
            if d < 0.2:
                QMessageBox.warning(self, "Video Editor", "The selected range is too short.")
                return
            total = d
            args = ["-ss", f"{a:.3f}", "-i", c.path, "-t", f"{d:.3f}"] + base_map
            if self.accurate.isChecked():
                args += venc_args(kind, crf) + ["-c:a", "copy"]
            else:
                args += ["-c", "copy", "-avoid_negative_ts", "make_zero"]
        elif t == "crop":
            x, y, w, h = self.crop.pixel_rect()
            args = ["-i", c.path] + base_map + ["-vf", f"crop={w}:{h}:{x}:{y}"] + venc_args(kind, crf) + ["-c:a", "copy"]
        elif t == "compress":
            args = ["-i", c.path] + base_map
            mh = self.maxh.currentData()
            if mh:
                args += ["-vf", f"scale=-2:min(ih\\,{mh})"]
            args += venc_args(kind, crf) + ["-c:a", "copy"]
        else:  # join
            if len(self.clips) < 2:
                QMessageBox.information(self, "Video Editor", "Add at least 2 clips to join.")
                return
            total = sum(x.duration for x in self.clips)
            if len({x.join_key() for x in self.clips}) == 1:
                self.tmpdir = tempfile.mkdtemp(prefix="vedit_")
                lst = Path(self.tmpdir) / "list.txt"
                lines = []
                for x in self.clips:
                    p = x.path.replace("\\", "/").replace("'", "'\\''")
                    lines.append(f"file '{p}'")
                lst.write_text("\n".join(lines), encoding="utf-8")
                args = ["-f", "concat", "-safe", "0", "-i", str(lst)] + base_map + ["-c", "copy"]
            else:
                args = join_reencode_args(self.clips, kind, crf)
        args += ["-movflags", "+faststart", out]

        self.out_path = out
        self.src_size = c.size if t != "join" else sum(x.size for x in self.clips)
        self.btn_save.setEnabled(False)
        self.btn_save.setText("Working…")
        self.progress.setValue(0)
        self.job = Job(args, total)
        self.job.progress.connect(self.progress.setValue)
        self.job.result.connect(self.on_done)
        self.job.start()

    def on_done(self, ok, msg):
        self.btn_save.setEnabled(True)
        self.btn_save.setText("SAVE")
        if self.tmpdir:
            shutil.rmtree(self.tmpdir, ignore_errors=True)
            self.tmpdir = None
        if ok:
            size = os.path.getsize(self.out_path)
            pct = size / self.src_size * 100 if self.src_size else 0
            box = QMessageBox(self)
            box.setWindowTitle("Done")
            box.setText(f"Saved:\n{self.out_path}\n\n{fmt_mb(self.src_size)}  →  {fmt_mb(size)}  ({pct:.0f}% of source)")
            show = box.addButton("Show in folder", QMessageBox.ButtonRole.ActionRole)
            box.addButton("OK", QMessageBox.ButtonRole.AcceptRole)
            box.exec()
            if box.clickedButton() is show and os.name == "nt":
                subprocess.Popen(["explorer", "/select,", os.path.normpath(self.out_path)])
        else:
            QMessageBox.critical(self, "Failed", msg)

    def closeEvent(self, e):
        if self.job:
            self.job.cancel()
        super().closeEvent(e)


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet(QSS)
    ico = resource("app.ico")
    if Path(ico).exists():
        app.setWindowIcon(QIcon(ico))
    if not (Path(FFMPEG).exists() or shutil.which("ffmpeg")):
        QMessageBox.critical(None, "FFmpeg not found",
                             "Put ffmpeg.exe and ffprobe.exe in the 'ffmpeg' folder next to this app, "
                             "or install FFmpeg and add it to PATH.")
        return 1
    w = MainWindow()
    w.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
