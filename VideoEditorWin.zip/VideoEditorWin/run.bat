@echo off
REM Run from source. Needs Python 3.10+ and ffmpeg.exe/ffprobe.exe in .\ffmpeg or on PATH.
python -m pip install -r requirements.txt
python main.py
