@echo off
REM Builds dist\VideoEditor\VideoEditor.exe  (needs ffmpeg.exe + ffprobe.exe inside .\ffmpeg)
python -m pip install -r requirements.txt pyinstaller
pyinstaller --noconfirm --windowed --name VideoEditor --icon app.ico --add-data "app.ico;." ^
  --add-binary "ffmpeg\ffmpeg.exe;ffmpeg" --add-binary "ffmpeg\ffprobe.exe;ffmpeg" main.py
echo.
echo Done: dist\VideoEditor\VideoEditor.exe
pause
